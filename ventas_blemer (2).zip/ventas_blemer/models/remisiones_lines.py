# -*- coding: utf-8 -*-
from odoo import api, fields, models


class Remisiones_lines(models.Model):
	_name = 'blemer.remisiones.lines'

	name = fields.Many2one('product.product', string="Producto", required=True)
	x_cantidad_line = fields.Float("Cantidad", required=True, default=1.00)
	x_unidad_de_medida = fields.Many2one('product.uom', string="Unidad de medida", related='name.uom_id', readonly=True)
	x_remision_id = fields.Many2one('blemer.remisiones')


class remisiones_tested(models.Model):
	_inherit = 'blemer.remisiones'